echo an exaple for case statement

echo enter x
read x
echo enter y
read y
echo enter op
read op

case $op in

add)  echo Addition operation 
      z=`expr $x + $y` ;;
sub)  echo subraction operation
      z=`expr $x - $y` ;;
mul)  echo Mult operation
      z=`expr $x \* $y` ;;

*)   echo "Entered wrong operator" ;;

esac

echo Total : $z
