#!/bin/sh
echo Enter x value
read x
echo Enter y
read y

# z=`expr $x \* $y`
z=$(($x+$y))

echo x value is $x
echo y value is $y
echo z value is $z
echo Hi thsi is my first shell sript
