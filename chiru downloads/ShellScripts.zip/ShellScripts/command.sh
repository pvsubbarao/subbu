echo an example for command line args

echo "First command $1"
echo "Second comamnd $2"
echo "No of command line params:   $#"

echo "Dollar zero : $0"
echo "Dollar Star: $*"
echo "Dollar Athedat: $@"
cho "Dolalr Dolalr: $$"
echo "Dollar quest: $?"
