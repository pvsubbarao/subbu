
echo An example for if condition statement
echo enter x
read x
echo enter y
read y

if [ $x -lt $y ]
then

  echo $y is bigger
else
  echo $x is bigger
fi
