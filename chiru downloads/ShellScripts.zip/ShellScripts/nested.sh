echo An example for nested if

echo enter x
read x
echo enter y
read y
echo enter operater
read op

if [ $op == "add" ]
then
   z=`expr $x + $y`

elif [ $op == "sub" ]
then
   z=`expr $x - $y`

elif [ $op == "mul" ]
then
   z=`expr $x \* $y`
else
  echo "You have entered a wrong operator; Please enter add/sub/mul"
fi

echo tottal is $z
