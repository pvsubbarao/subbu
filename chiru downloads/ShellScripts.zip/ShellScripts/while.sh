echo an example for a while loop

i=6
j=$i
while [ $i -gt 1 ]
do
i=`expr $i - 1`
j=`expr $j \* $i`


done
echo j value is $j

exit 0
a=0

while [ $a -lt 20 ]
do

echo a value is $a
a=`expr $a + 2`

done




i=10

while [ $i -le 100 ]
do

  echo i value is $i
  i=`expr $i + 10`
done

