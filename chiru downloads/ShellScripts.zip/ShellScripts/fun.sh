


function add()
{
  tot=`expr $1 + $2` 
  echo $tot
}
function mul()
{
  tot=`expr $1 \* $2`
  echo $tot
}
function sub()
{
  tot=`expr $1 - $2`
  echo $tot
}


#echo enter x
#read x
#echo enter y
#read y
#echo enter opertion
#read op

x=$1
y=$2
op=$3


case $op in 

add)  tot=$(add $x $y)
      echo Total is : $tot ;;
sub)  tot=$(sub $x $y)
      echo Total is : $tot ;;
mul)  tot=$(mul $x $y)
      echo Total is : $tot ;;
*)   echo You have entered a wrong operation ;;

esac

