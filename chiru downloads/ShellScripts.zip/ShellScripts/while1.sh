

while read line
do

 echo "* $line "

done < Hello.txt
