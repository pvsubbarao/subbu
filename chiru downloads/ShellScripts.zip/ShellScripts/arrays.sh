echo arrays example

arr=(Hi Hello How are you)

echo "Total array: ${arr[@]}"
echo "Element 1  :${arr[2]}"
echo "Length:    ${#arr[@]}"

for i in ${arr[@]}
do

  count=`echo $i | wc -c`
  echo "count is : $count"

done
