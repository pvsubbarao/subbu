echo an example for for loop

for i in `find . -name "*.sh"`
do

 noLines=`cat $i | wc -l` 
 echo "i value is $i --> $noLines"

done
