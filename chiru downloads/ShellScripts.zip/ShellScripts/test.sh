
echo Print the lines which contains more then 10 chars


for file in `find . -name "*.txt"`
do

echo "FILE : $file started"
i=1
while [ $i -le  `cat $file | wc -l` ]
do

  noChars=`head -$i Hello.txt | wc -c`
  if [ $noChars -gt 10 ]
  then
    echo "Line $i --> $noChars"

  fi
  i=`expr $i + 1`
done


done
